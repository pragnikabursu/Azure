This folder contains notebooks and code that make Databricks Administration easy.
